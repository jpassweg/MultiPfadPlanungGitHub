Start Main.java for Simulation
You can change the inputFile if you want to change the map and agents or using the bugged editor