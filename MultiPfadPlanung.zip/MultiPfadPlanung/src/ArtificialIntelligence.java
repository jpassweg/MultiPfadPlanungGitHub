/**
 * 
 * @author Jonas Passweg
 * @version 1.1
 *
 */
public interface ArtificialIntelligence {
	public Object decide();
}
