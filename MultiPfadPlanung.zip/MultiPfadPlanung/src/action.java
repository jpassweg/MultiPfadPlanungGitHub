/**
 * 
 * @author Jonas Passweg
 * @version 1.2
 * 
 * This class includes all possible actions a Agent can perform.
 */
public class action {
	static Object MOVE_EAST = new Object();	//move east
	static Object MOVE_WEST = new Object(); //move west
	static Object MOVE_SOUTH = new Object();//move south
	static Object MOVE_NORTH = new Object();//move north
	static Object WAIT = new Object();		//do nothing
}
