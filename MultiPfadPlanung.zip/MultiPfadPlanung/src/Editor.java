

public class Editor {
	
	/**
	 * main of Editor
	 * @param args
	 */
	public static void main(String[] args) {
		//starting new Editor GUI
		EditorGUI ed = new EditorGUI();
		ed.startEditorGUI(args);
		
		//THE END
	} //end of long main
} //end of long class Editor
